---
title: 关于知乎 "哪些知识越了解越觉得『对这个世界很绝望』？"
abbrlink: 1993181253
date: 2020-04-18 11:53:40
tags:
---

今天偶然在知乎上看到的一篇回答，刷新了我对90后现状的认识，以及资本主义的含义。

引用文中的一张图，90后新名词：

![新世界](https://chenning02.github.io/Document/diary-img/zhihu_xinqiongren.jpg)

原文链接：[哪些知识越了解越觉得『对这个世界很绝望』？ - Mushroobby的回答 - 知乎](https://www.zhihu.com/question/308429562/answer/647578201)

