---
title: "CSS选择器总结"
categories:
  - 前端
tags:
  - CSS
date: 2020-06-04T09:00:30+08:00
draft: false
---

## 文章

1. 思否：https://segmentfault.com/a/1190000009887677

2. 知乎：https://zhuanlan.zhihu.com/p/89314067



