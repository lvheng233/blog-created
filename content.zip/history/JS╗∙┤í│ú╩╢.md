---
title: JS基础常识
date: 2019-08-27 23:00:41
categories:
- 前端
tags:
- JavaScript
---

## 七种数据类型
- number 
- string 
- boolean
- symbol
- null 
- undefined
- object

## 五个 false 值
- null 
- undefined
- 0 
- NaN
- '' ( 空字符串 )