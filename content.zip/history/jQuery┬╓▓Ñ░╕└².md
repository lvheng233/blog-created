---
title: jQuery制作轮播
date: 2019-10-03 07:05:13
---

使用  jQuery 写轮播

**写代码要讲究 内容，样式，行为的分离**

- html - 内容

- css - 样式

- js - 行为